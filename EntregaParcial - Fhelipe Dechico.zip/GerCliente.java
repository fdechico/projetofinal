import java.util.ArrayList;
//Fhelipe Vinicios Dechico - RA: 2623390
public final class GerCliente{
	private Leitura l = new Leitura();
	private Cliente cli;
	private ArrayList<Cliente> bdCli = new ArrayList<Cliente>();

	public ArrayList<Cliente> getBdCli(){
		return bdCli;
	}

	public Cliente consultaCliente(Cliente cli){
		for(Cliente cliente: bdCli){
			if(cli.getCpf() == cliente.getCpf()){
				return cliente;
			}
		}
		return null;
	}

	public Cliente inserirCliente(Cliente cli){
		int flag = 0;
		cli.setNome(l.entDados("Digite o nome do cliente: "));
		do{
			try{
				cli.setCpf(Long.parseLong(l.entDados("Digite o cpf do cliente:")));
				flag = 1;
			}
			catch(CpfDiferenteOnzeException ndo){
				System.out.println("Insira um novo cpf com 11 digitos positivos");
			}
			catch(NumberFormatException nfe){
				System.out.println("O cpf deve ser um numero inteiro, positivo de 11 digitos");
			}
		}while(flag == 0);

		flag = 0;
		
		if(consultaCliente(cli) == null){
				cli.setEmail(l.entDados("Digite o email do cliente: "));
				cli.setProfissao(l.entDados("Digite a profissao do cliente: "));

				do{
					try{
						cli.setTelefone(l.entDados("Digite o telefone do cliente: "));
						flag = 1;
					}
					catch(NaoeDigitoException nede){
						System.out.println("O telefone deve ser apenas numeros");
					}
				}while(flag == 0);

				flag = 0;
				
				do{
					try{
						cli.setIdade(Integer.parseInt(l.entDados("Digite a idade do cliente: ")));
						flag = 1;
					}
					catch(IdadeMaiorException ime){
						System.out.println("Como a idade maxima permitida e 80 anos nao e possivel inserir este cliente");
						return null;
					}
					catch(NumberFormatException nfe){
						System.out.println("A idade deve ser um numero inteiro e positivo, tente novamente");
					}
					catch(NumeroNegativoException nne){
						System.out.println("A idade deve ser um numero positivo, tente novamente");
					}
				}while(flag == 0);
				
				bdCli.add(cli);
				return cli;
		}

		return null;
	}

	public Cliente deletarCliente(Cliente cli){
		Cliente cliDel = consultaCliente(cli);
		if(cliDel != null){
			bdCli.remove(cliDel);
			return null;
		}
		return cli;
	}

	public Cliente atualizaCliente(Cliente cli){
		int flag = 0;
		for(int i = 0; i < bdCli.size(); i++){
			if(cli.getCpf() == bdCli.get(i).getCpf()){
            	cli = bdCli.get(i);
                cli.setNome(l.entDados("Insira o novo nome do cliente: "));
                do{
					try{
						cli.setIdade(Integer.parseInt(l.entDados("Digite a nova idade do cliente: ")));
						flag = 1;
					}
					catch(IdadeMaiorException ime){
						System.out.println("Como a idade maxima permita e 80 anos nao e possivel inserir este cliente");
					}
					catch(NumberFormatException nfe){
						System.out.println("A idade deve ser um numero inteiro e positivo");
					}
					catch(NumeroNegativoException nne){
						System.out.println("A idade deve ser um numero positivo");
					}
				}while(flag == 0);
                cli.setEmail(l.entDados("Insira o novo email: "));
                cli.setProfissao(l.entDados("Insira a nova profissao: "));

                try{
					cli.setTelefone(l.entDados("Insira o novo telefone: "));
				}
				catch(NaoeDigitoException nede){
					System.out.println("O telefone deve ser apenas numeros");
				}
                
                bdCli.set(i, cli);  
                return bdCli.get(i);
			}
		}
		return null;
	}
}

